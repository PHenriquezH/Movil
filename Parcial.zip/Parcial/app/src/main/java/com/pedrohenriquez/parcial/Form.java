package com.pedrohenriquez.parcial;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Form extends AppCompatActivity {

    Button boton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);


    }
    public void mostrarAlert(View view) {
        mostrarDialogo();
    }

    private void mostrarDialogo(){
        new AlertDialog.Builder(this).setTitle("Aviso de confirmación")
                .setMessage("¿Desea continuar con las opciones seleccionadas?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Form.this, Cont.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.d("Mensaje","Se cancelo la acción");
                    }
                })
                .show();
    }


}